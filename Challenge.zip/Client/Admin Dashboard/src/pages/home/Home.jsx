import "./home.css";

const Home = () => {
  return <div></div>;
};

export default Home;
