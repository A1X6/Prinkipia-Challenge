import React from "react";
import JobList from "../../components/jobList/JobList";
import "./jobs.css";

const Jobs = () => {
  return (
      <JobList />
  );
};

export default Jobs;
