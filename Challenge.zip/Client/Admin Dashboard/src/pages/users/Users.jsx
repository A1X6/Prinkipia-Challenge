import "./users.css";

const Users = () => {
  return <div></div>;
};

export default Users;
