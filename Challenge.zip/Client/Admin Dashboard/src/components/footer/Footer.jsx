import "./footer.css";

const Footer = () => {
  return (
    <div className="footer">
      <span>Admin</span>
      <span>© Admin Dashboard</span>
    </div>
  )
}

export default Footer;
